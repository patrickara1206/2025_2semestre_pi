/*---------- INICIO Funcionalidade do menu mobile ----------*/
window.addEventListener("load", function (event) {
  var acc = document.getElementsByClassName("accordion");
  var i;

  for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function () {
      /* Toggle between adding and removing the "active" class,
      to highlight the button that controls the panel */
      this.classList.toggle("active");

      /* Toggle between hiding and showing the active panel */
      var panel = this.nextElementSibling;
      if (panel.style.display === "block") {
        panel.style.display = "none";
      } else {
        panel.style.display = "block";
      }
    });
  }
  var menusComSubItems = document.querySelectorAll(".menu-item-has-children");

  if (window.innerWidth >= 1024) {
    for (var i = 0; i < menusComSubItems.length; i++) {
      if (menusComSubItems[i].classList.contains("has-mega-menu")) {
        menusComSubItems[i].classList.remove("menu-item-has-children");
      }
    }
  }

  if (window.innerWidth < 1024) {
    for (var i = 0; i < menusComSubItems.length; i++) {
      menusComSubItems[i].addEventListener("click", function () {
        this.children[1].classList.add("sub-menu-ativo");
        //console.log("clicou");
      });
    }
  }

  const btnAbreMenu = document.querySelector("#menu-mobile__btn");
  const btnFechaMenu = document.querySelector(
    ".main-menu-container i.fa-times"
  );
  const menuContainer = document.querySelector(".main-menu-container");

  btnAbreMenu.addEventListener("click", function () {
    menuContainer.style.display = "block";
  });

  btnFechaMenu.addEventListener("click", function () {
    menuContainer.style.display = "none";
  });
});
/*---------- FIM Funcionalidade do menu mobile ----------*/

/*---------- INICIO Funcionalidade do Slider de imagens ----------*/

//   const sliderInova = document.querySelector(".post-slider__container");
//   const controleDireita = document.querySelector("#controle-direita");
//   const controleEsquerda = document.querySelector("#controle-esquerda");
//   const larguraItem = document.querySelector(".item").offsetWidth;

//   setInterval(() => {
//     if (sliderInova.scrollLeft === (sliderInova.scrollWidth - larguraItem)) {
//      sliderInova.scrollBy(-sliderInova.scrollWidth, 0);
//    } else {
//      sliderInova.scrollBy(larguraItem, 0);
//    }
//  }, 1000);
0;
//   controleDireita.addEventListener("click", function() {
//     sliderInova.scrollBy(larguraItem, 0);
//   } )
//   controleEsquerda.addEventListener("click", function() {
//     sliderInova.scrollBy(-larguraItem, 0);
//   } )

//---//

if (document.querySelector("#post-slider__container")) {
  let tempoTransicao = 7000,
    indexItemAtual = 0,
    items = document.querySelectorAll("#post-slider__container .item");
  totalItems = items.length;

  function proximoItem() {
    //console.log(totalItems);
    //console.log(items[indexItemAtual]);
    items[indexItemAtual].classList.remove("ativo");

    indexItemAtual === totalItems - 1 ? (indexItemAtual = 0) : indexItemAtual++;

    items[indexItemAtual].classList.add("ativo");
  }

  function itemAnterior() {
    items[indexItemAtual].classList.remove("ativo");

    if (indexItemAtual === 0) indexItemAtual = totalItems;

    indexItemAtual--;

    items[indexItemAtual].classList.add("ativo");
  }

  function iniciarSlider() {
    setInterval(() => {
      // troca de image
      proximoItem();
    }, tempoTransicao);
  }

  const controleEsquerda = document.querySelector("#controle-esquerda");
  const controleDireita = document.querySelector("#controle-direita");

  controleDireita.addEventListener("click", () => {
    proximoItem();
  });

  controleEsquerda.addEventListener("click", () => {
    itemAnterior();
  });

  window.addEventListener("load", iniciarSlider);
}
//---//

/**
 * Esconde Eventos com registro encerrado no site Inova CPS
 */
if (window.location.href === "https://inova.cps.sp.gov.br/academia-inovacps/") {
  const todosEventos = document.querySelectorAll(".qem");

  for (i = 0; i <= todosEventos.length - 1; i++) {
    if (
      todosEventos[i].children[1].children[5].innerText ===
        "RESERVAS ENCERRADAS" ||
      todosEventos[i].children[1].children[4].innerText ===
        "RESERVAS ENCERRADAS"
    ) {
      todosEventos[i].style.display = "none";
    }
  }
}

const popupContainer = document.querySelector(".popup-cf7-enviado__container");
const popupBtnFechar = document.querySelector(
  ".popup-cf7-enviado__conteudo .fa-times-circle"
);

//popupBtnFechar.addEventListener("click", () => {
  //popupContainer.style.display = "none";
//});

/*---------- FIM Funcionalidade do Slider de imagens ----------*/

/*---------- INICIO Abrir todos os links do site em uma nova aba ----------*/
const links = document.querySelectorAll(".single-post .cps-texto-conteudo a");
const len = links.length;

for (let i = 0; i < len; i++) {
  links[i].target = "_blank";
  links[i].rel = "noreferrer noopener";
}

const linkspagination = document.querySelectorAll(".single-post .notarget a");
const lens = linkspaginatio.length;

for (let i = 0; i < lens; i++) {
  linkspaginatio[i].target = "_self";
  linkspaginatio[i].rel = "noreferrer noopener";
}
/*---------- INICIO Abrir todos os links do site em uma nova aba ----------*/
// const inputTeste = document.querySelector("#pesquisa-teste");

// if (inputTeste) {
//   inputTeste.addEventListener("keyup", function (element) {
//     const termoDeBusca = element.target.value;

//     fetch(
//       `http://localhost:8080/master/wp-json/cps/v1/cursos?search=${termoDeBusca}`
//     )
//       .then((response) => response.json())
//       .then((response) => {
//         console.log(response);
//       });
//   });
// }

(function ($) {
  const inputDeBusca = $("#pesquisa-cursos-etec");
  let timerPesquisa = "";
  let pesquisaAnterior;

  inputDeBusca.on("keyup", pegaResultadosDeBusca);

  function pegaResultadosDeBusca(element) {
    if (element.target.value != pesquisaAnterior) {
      clearTimeout(timerPesquisa);

      if (element.target.value) {
        timerPesquisa = setTimeout(function () {
          $(".cursos-etec").html(
            '<br><strong>Carregando</strong> <i class="fas fa-circle-notch fa-spin"></i>'
          );

          $.getJSON(
            `https://www.cps.sp.gov.br/wp-json/wp/v2/cursos-etec?search=${element.target.value}&per_page=100`,
            function (results) {
              if (results.length > 0) {
                $(".cursos-etec").html(`
                  <hr>
                  <h4>Resultados de busca para: ${element.target.value}</h4>
              `);

                results.map((result) => {
                  $(".cursos-etec").append(`
                  <a href="${result.link}">${result.title.rendered}</a><br>
                `);
                });
              } else {
                $(".cursos-etec").html(`
                <hr>
                <h5>Nenhum resultado de busca encontrado.</h5>
              `);
              }
            }
          );
        }, 200);
      } else {
        $(".cursos-etec").html("");
      }
    }

    pesquisaAnterior = element.target.value;
  }
})(jQuery);

(function ($) {
  const inputDeBusca = $("#pesquisa-unidades-etec");
  let timerPesquisa = "";
  let pesquisaAnterior;

  inputDeBusca.on("keyup", pegaResultadosDeBuscaEtecs);

  function pegaResultadosDeBuscaEtecs(element) {
    if (element.target.value != pesquisaAnterior) {
      clearTimeout(timerPesquisa);

      if (element.target.value) {
        timerPesquisa = setTimeout(function () {
          $(".unidades-etec").html(
            '<br><strong>Carregando</strong> <i class="fas fa-circle-notch fa-spin"></i>'
          );

          $.getJSON(
            `https://www.cps.sp.gov.br/wp-json/wp/v2/etecs?search=${element.target.value}&per_page=100`,
            function (results) {
              if (results.length > 0) {
                $(".unidades-etec").html(`
                  <hr>
                  <h4>Resultados de busca para: ${element.target.value}</h4>
              `);

                results.map((result) => {
                  $(".unidades-etec").append(`
                  <a href="${result.link}">${result.title.rendered}</a><br>
                `);
                });
              } else {
                $(".unidades-etec").html(`
                <hr>
                <h5>Nenhum resultado de busca encontrado.</h5>
              `);
              }
            }
          );
        }, 200);
      } else {
        $(".unidades-etec").html("");
      }
    }

    pesquisaAnterior = element.target.value;
  }
})(jQuery);

// Pesquisas Fatec

(function ($) {
  const inputDeBusca = $("#pesquisa-cursos-fatec");
  let timerPesquisa = "";
  let pesquisaAnterior;

  inputDeBusca.on("keyup", pegaResultadosDeBusca);

  function pegaResultadosDeBusca(element) {
    if (element.target.value != pesquisaAnterior) {
      clearTimeout(timerPesquisa);

      if (element.target.value) {
        timerPesquisa = setTimeout(function () {
          $(".cursos-fatec").html(
            '<br><strong>Carregando</strong> <i class="fas fa-circle-notch fa-spin"></i>'
          );

          $.getJSON(
            `https://www.cps.sp.gov.br/wp-json/wp/v2/cursos-fatec?search=${element.target.value}&per_page=100`,
            function (results) {
              if (results.length > 0) {
                $(".cursos-fatec").html(`
                  <hr>
                  <h4>Resultados de busca para: ${element.target.value}</h4>
              `);

                results.map((result) => {
                  $(".cursos-fatec").append(`
                  <a href="${result.link}">${result.title.rendered}</a><br>
                `);
                });
              } else {
                $(".cursos-fatec").html(`
                <hr>
                <h5>Nenhum resultado de busca encontrado.</h5>
              `);
              }
            }
          );
        }, 200);
      } else {
        $(".cursos-fatec").html("");
      }
    }
    pesquisaAnterior = element.target.value;
  }
})(jQuery);

(function ($) {
  const inputDeBusca = $("#pesquisa-unidades-fatec");
  let timerPesquisa = "";
  let pesquisaAnterior;

  inputDeBusca.on("keyup", pegaResultadosDeBuscaFatecs);

  function pegaResultadosDeBuscaFatecs(element) {
    if (element.target.value != pesquisaAnterior) {
      clearTimeout(timerPesquisa);

      if (element.target.value) {
        timerPesquisa = setTimeout(function () {
          $(".unidades-fatec").html(
            '<br><strong>Carregando</strong> <i class="fas fa-circle-notch fa-spin"></i>'
          );

          $.getJSON(
            `https://www.cps.sp.gov.br/wp-json/wp/v2/fatecs?search=${element.target.value}&per_page=100`,
            function (results) {
              if (results.length > 0) {
                $(".unidades-fatec").html(`
                  <hr>
                  <h4>Resultados de busca para: ${element.target.value}</h4>
              `);

                results.map((result) => {
                  $(".unidades-fatec").append(`
                  <a href="${result.link}">${result.title.rendered}</a><br>
                `);
                });
              } else {
                $(".unidades-fatec").html(`
                <hr>
                <h5>Nenhum resultado de busca encontrado.</h5>
              `);
              }
            }
          );
        }, 200);
      } else {
        $(".unidades-fatec").html("");
      }
    }

    pesquisaAnterior = element.target.value;
  }
})(jQuery);

// (function ($) {
//   const listagemFontesInfo = $("#listagem-fontes-informacao");

//   window.addEventListener("load", carregaFontesInformacao);

//   function carregaFontesInformacao() {
//     listagemFontesInfo.html(
//       '<br><strong>Carregando</strong> <i class="fas fa-circle-notch fa-spin"></i>'
//     );

//     $.getJSON(
//       `http://sites-cpsnew-homologacao.azurewebsites.net/cgd/wp-json/wp/v2/cgd-fontes-info`,
//       function (results) {
//         if (results.length > 0) {
//           console.log(results);
//           listagemFontesInfo.html("");
//           results.map((result) => {
//             listagemFontesInfo.append(`
//             <a href="${result.acf.endereco_de_acesso}">${result.title.rendered} - (${result.acf.titulo})</a><br>
//             <p>Autor: ${result.acf.autoria} | Eixo TecnolÃ³gico: ${result.acf.eixo_tecnologico}</p>
//             <p>Fonte ${result.acf.fonte[0]} | Tipo de Fonte: ${result.acf.tipo_de_fonte}</p>
//             <p>Resumo:</p>
//             <p>${result.acf.resumo}</p>
//             <hr>
//           `);
//           });
//         } else {
//           listagemFontesInfo.html(`
//           <hr>
//           <h5>Nenhum resultado de busca encontrado.</h5>
//         `);
//         }
//       }
//     );
//   }
// })(jQuery);