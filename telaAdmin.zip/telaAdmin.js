document.addEventListener('DOMContentLoaded', function() {
    // --- LÓGICA DE NAVEGAÇÃO ENTRE SEÇÕES ---
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link[data-target]');
    const sections = document.querySelectorAll('.conteudo-secao');

    navLinks.forEach(link => {
        link.addEventListener('click', (event) => {
            event.preventDefault();
            
            const targetId = link.getAttribute('data-target');
            
            // Atualiza seções
            sections.forEach(section => {
                section.classList.toggle('ativo', section.id === targetId);
            });

            // Atualiza links
            navLinks.forEach(navLink => {
                navLink.classList.toggle('active', navLink.getAttribute('data-target') === targetId);
            });
        });
    });

    // --- LÓGICA DO MODAL ---
    const userForm = document.getElementById('formUsuario');
    const userModal = new bootstrap.Modal(document.getElementById('userModal'));
    
    userForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const nome = document.getElementById('nome').value;
        alert(`Usuário "${nome}" cadastrado com sucesso! (Simulação)`);
        userForm.reset();
        userModal.hide();
    });

    // --- LÓGICA DE ACESSIBILIDADE ---
    const body = document.body;
    const html = document.documentElement;

    // Modo Escuro
    const darkModeToggle = document.getElementById('toggle-dark-mode');
    darkModeToggle.addEventListener('click', () => {
        body.classList.toggle('dark-mode');
        // Salva a preferência
        localStorage.setItem('darkMode', body.classList.contains('dark-mode'));
    });

    // Carrega a preferência de Modo Escuro
    if (localStorage.getItem('darkMode') === 'true') {
        body.classList.add('dark-mode');
    }

    // Controle de Fonte
    const increaseFontBtn = document.getElementById('increase-font');
    const decreaseFontBtn = document.getElementById('decrease-font');
    const FONT_STEP = 0.1; // Incremento/decremento em rem

    increaseFontBtn.addEventListener('click', () => changeFontSize(FONT_STEP));
    decreaseFontBtn.addEventListener('click', () => changeFontSize(-FONT_STEP));

    function changeFontSize(step) {
        const currentSize = parseFloat(getComputedStyle(html).getPropertyValue('--font-size-base'));
        const newSize = Math.max(0.7, currentSize + step); // Limite mínimo de 0.7rem
        html.style.setProperty('--font-size-base', `${newSize}rem`);
    }
    
    // Modos de Daltonismo
    const colorModeLinks = document.querySelectorAll('#accessibilityDropdown [data-mode]');
    colorModeLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const mode = link.getAttribute('data-mode');
            body.classList.remove('protanopia', 'deuteranopia', 'tritanopia');
            if(mode !== 'normal') {
                body.classList.add(mode);
            }
        });
    });

});
